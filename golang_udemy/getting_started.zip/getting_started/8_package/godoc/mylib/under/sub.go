package under

import "fmt"

func Hello() {
	fmt.Println("Hello!")
}
