package mylib

import "fmt"

func Say() {
	fmt.Println("Human!")
}
