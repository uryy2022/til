Copyright (c) 2018 Jun Sakai 

Please be considerate and refrain from using codes introduced on the online courses,
youtube videos, blog, and e-books for business purposes. Use of a couple lines of 
codes introduced in the blog and  affiliates presented as a link for this online 
course is allowed. Please refrain from releasing or redistributing source codes in 
places such as Github. The use of the code for this app is allowed for business purposes, 
but please follow the above mentioned rules. If you have any questions, please do 
not hesitate to contact me.

Jun Sakai <http://sakaijunsoccer.appspot.com/en/contact>
